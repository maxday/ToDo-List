<?php 
//just to make the loading time a little bit longer
sleep(1);?>
<h3>This is AJAX Content</h3>
<p>last load: <?php echo date('r');?></p>